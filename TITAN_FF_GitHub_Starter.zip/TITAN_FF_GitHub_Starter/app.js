const dialog = document.getElementById('auth-dialog');
const statusBox = document.getElementById('auth-status');
const toast = document.getElementById('toast');
let authMode = 'login';
function showAuth(mode='login') {
  setMode(mode);
  if (typeof dialog.showModal === 'function') dialog.showModal();
  else alert('Your browser does not support this login dialog. Please update your browser.');
}
function setMode(mode) {
  authMode = mode;
  document.querySelectorAll('.auth-tabs button').forEach(b => b.classList.toggle('active', b.dataset.mode === mode));
  document.getElementById('auth-title').innerHTML = mode === 'signup' ? 'Create your <span>TITAN FF</span> account' : 'Sign in to <span>TITAN FF</span>';
  document.getElementById('name-label').classList.toggle('hidden', mode !== 'signup');
  document.getElementById('confirm-label').classList.toggle('hidden', mode !== 'signup');
  document.getElementById('terms-label').classList.toggle('hidden', mode !== 'signup');
  document.getElementById('password').autocomplete = mode === 'signup' ? 'new-password' : 'current-password';
  statusBox.textContent = 'Authentication is not configured in this static starter. No account will be created.';
}
function notify(message) {
  toast.textContent = message; toast.classList.add('show');
  clearTimeout(notify.timer); notify.timer = setTimeout(() => toast.classList.remove('show'), 3200);
}
document.getElementById('open-login').addEventListener('click', () => showAuth('login'));
document.getElementById('hero-join').addEventListener('click', () => showAuth('signup'));
document.getElementById('banner-join').addEventListener('click', () => showAuth('signup'));
document.getElementById('close-dialog').addEventListener('click', () => dialog.close());
document.querySelectorAll('.auth-tabs button').forEach(b => b.addEventListener('click', () => setMode(b.dataset.mode)));
document.getElementById('toggle-password').addEventListener('click', e => {
  const input = document.getElementById('password');
  input.type = input.type === 'password' ? 'text' : 'password';
  e.currentTarget.textContent = input.type === 'password' ? 'Show' : 'Hide';
});
document.getElementById('auth-form').addEventListener('submit', e => {
  e.preventDefault();
  const email = document.getElementById('email').value.trim();
  const password = document.getElementById('password').value;
  if (!email || password.length < 8) { statusBox.textContent = 'Enter a valid email and a password with at least 8 characters.'; return; }
  if (authMode === 'signup') {
    if (!document.getElementById('display-name').value.trim()) { statusBox.textContent = 'Enter your display name.'; return; }
    if (password !== document.getElementById('confirm-password').value) { statusBox.textContent = 'Passwords do not match.'; return; }
    if (!document.getElementById('accept-terms').checked) { statusBox.textContent = 'Please accept the Terms and Privacy Policy.'; return; }
  }
  statusBox.textContent = 'Setup required: connect a real authentication provider (for example, Firebase Authentication) before login or account creation can work. No account was created.';
});
document.getElementById('google-login').addEventListener('click', () => {
  statusBox.textContent = 'Google sign-in is not configured yet. Enable Google in your authentication provider and connect its SDK before using this button.';
});
document.getElementById('phone-login').addEventListener('click', () => {
  statusBox.textContent = 'Phone OTP is not configured yet. A real OTP provider, authorized domain and server/provider setup are required.';
});
document.querySelectorAll('.register-action').forEach(b => b.addEventListener('click', () => notify('Event details and registration require a connected backend. This card is sample content.')));
function updateClock() {
  const now = new Date();
  const time = new Intl.DateTimeFormat('en-IN', {timeZone:'Asia/Kolkata', hour:'2-digit', minute:'2-digit', second:'2-digit', hour12:true}).format(now);
  const date = new Intl.DateTimeFormat('en-IN', {timeZone:'Asia/Kolkata', day:'2-digit', month:'short', year:'numeric'}).format(now);
  document.getElementById('india-clock').textContent = `${time} · ${date} IST`;
}
updateClock(); setInterval(updateClock, 1000);
