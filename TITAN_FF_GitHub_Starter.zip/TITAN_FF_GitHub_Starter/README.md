# TITAN FF — GitHub Pages starter

A responsive static front-end prototype for a premium black/crimson gaming community portal.

## Files
- `index.html` — landing page and login/signup dialog
- `style.css` — responsive design, animation and styling
- `app.js` — UI interactions, IST clock and honest configuration messages
- `favicon.svg` — original simple brand mark
- `privacy.html`, `terms.html`, `rules.html`, `contact.html` — starter policy pages

## Publish with GitHub Pages
1. Create a GitHub repository.
2. Upload all files in this folder to the repository root.
3. Open **Settings → Pages**.
4. Under build/deployment, choose **Deploy from a branch**.
5. Select the `main` branch and `/ (root)`, then Save.
6. Open the published URL shown on the Pages settings screen.

## Important limitations
This is a **front-end starter only**. It does not have a backend, database, real authentication, Google OAuth, phone OTP, admin role enforcement, real tournament registration, or a working API. The login form intentionally does not pretend to sign in or create accounts.

To enable real authentication, connect Firebase Authentication (Email/Password and Google) or another provider and configure authorized domains. Phone OTP requires a supported provider and its verification setup. For admin access, tournament results, reports, posts and user data, use a backend/database with server-side authorization rules. Never put service-account credentials or private secrets in frontend files.

All rankings and event cards are illustrative sample content. TITAN FF is an independent community project and is not affiliated with Garena or Free Fire.
